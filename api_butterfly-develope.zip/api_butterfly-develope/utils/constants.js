export const DB_NAME = "vaidik_diamond";
export const MONGODB_URI = "mongodb+srv://ndholariya5:navin123@cluster0.guuomo2.mongodb.net";
// export const MONGODB_URI = `mongodb+srv://ndholariya5:navin123@cluster0.guuomo2.mongodb.net/${DB_NAME}?retryWrites=true&w=majority&appName=Cluster0`;
export const CORS_ORIGIN = "*";

export const ACCESS_TOKEN_SECRET = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
export const ACCESS_TOKEN_EXPIRY = "1d";
export const REFRESH_TOKEN_SECRET = "eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyf";
export const REFRESH_TOKEN_EXPIRY = "10d";

export const CLOUDINARY_CLOUD_NAME = "dlqpqp9ty";
export const CLOUDINARY_API_KEY = "747399459312417";
export const CLOUDINARY_API_SECRET = "mfuHi4833DKbfkH4nL5I3DbDrR0";