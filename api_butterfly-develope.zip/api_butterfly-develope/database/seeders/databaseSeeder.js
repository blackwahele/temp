import userSeed from "./userSeeder.js";

(function(){
    userSeed();
})();

// node database/seeders/databaseSeeder.js