import mongoose from "mongoose";

//Define Schema - With Mongoose, everything is derived from a Schema.
const nextGameTimeSchema = new mongoose.Schema(
    {
        timeInMin : {
            type: Number,
            required: true,
            trim: true,
            match: [/^[0-9]+$/, 'Please Enter Valid Number.'],
            maxLength:5
        },  
        status : { type: String,  enum: ['Active', 'Suspended'] },
        isDeleted : Boolean     
    },
    {
        timestamps: {
            createdAt: 'created_at', // to change createdAt name to created_at
            updatedAt: 'updated_at' // to change updatedAt name to updated_at
        }
    }
);

mongoose.models = {};

//compile shcema into model
/* 
 *   A model is a class with which we construct documents.
 *   In this case, each document will be a Card_master with properties and behaviors as declared in our schema. 
*/
const Next_game_time = mongoose.models.next_game_times || mongoose.model('Next_game_time',nextGameTimeSchema);
export default Next_game_time;